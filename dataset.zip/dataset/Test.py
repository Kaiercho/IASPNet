import open3d as o3d
import numpy as np


def read_txt(file_path):
    """
    读取txt格式的点云数据，返回numpy数组
    """
    return np.loadtxt(file_path)


def save_txt(data, file_path):
    """
    将numpy数组保存为txt格式
    """
    np.savetxt(file_path, data, fmt='%f')


def main(input_file, output_file, alpha=0.03):
    # Step 1: 读取点云数据
    point_cloud_data = read_txt(input_file)
    points = point_cloud_data[:, :3]  # 前三维度的坐标
    labels = point_cloud_data[:, -1]  # 最后一维的标签

    # 使用Open3D创建点云对象
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(points)

    # Step 2: 提取点云轮廓点
    tetra_mesh, pt_map = o3d.geometry.TetraMesh.create_from_point_cloud(pcd)
    alpha_shape = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha)
    # mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha)

    # 提取顶点
    contour_points = np.asarray(alpha_shape.vertices)

    # Step 3: 匹配标签
    # 创建一个新的数组存储轮廓点和对应的标签
    contour_points_with_labels = []
    for point in contour_points:
        # 找到与轮廓点最接近的原始点
        distances = np.linalg.norm(points - point, axis=1)
        closest_idx = np.argmin(distances)
        label = labels[closest_idx]
        contour_points_with_labels.append(np.append(point, label))

    contour_points_with_labels = np.array(contour_points_with_labels)

    # Step 4: 保存结果
    save_txt(contour_points_with_labels, output_file)

    # 可视化输入点云和提取后的轮廓点
    o3d.visualization.draw_geometries([pcd], window_name='输入点云')
    contour_pcd = o3d.geometry.PointCloud()
    contour_pcd.points = o3d.utility.Vector3dVector(contour_points)
    o3d.visualization.draw_geometries([contour_pcd], window_name='轮廓点云')


if __name__ == "__main__":
    input_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    output_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    main(input_file, output_file)
