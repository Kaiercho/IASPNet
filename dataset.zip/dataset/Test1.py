import numpy as np


def read_point_cloud_from_txt(file_path):
    """
    从txt文件中读取点云数据
    """
    point_cloud = np.loadtxt(file_path, delimiter=' ')
    return point_cloud


def farthest_point_sampling(point_cloud, num_samples):
    """
    最远点采样算法
    :param point_cloud: 输入点云，形状为(N, 3)
    :param num_samples: 需要采样的点数
    :return: 采样后的点云索引和采样后的点云
    """
    N, D = point_cloud.shape
    centroids = np.zeros((num_samples,), dtype=np.int32)
    distances = np.ones((N,)) * 1e10
    farthest = np.random.randint(0, N)
    for i in range(num_samples):
        centroids[i] = farthest
        centroid = point_cloud[farthest, :]
        dist = np.sum((point_cloud - centroid) ** 2, axis=1)
        mask = dist < distances
        distances[mask] = dist[mask]
        farthest = np.argmax(distances)
    sampled_points = point_cloud[centroids]
    return centroids, sampled_points


def save_point_cloud_to_txt(file_path, point_cloud):
    """
    将点云数据保存到txt文件中
    """
    np.savetxt(file_path, point_cloud, delimiter=' ')


def main(input_file, output_file):
    # 读取点云数据
    point_cloud = read_point_cloud_from_txt(input_file)

    # 提取前三维数据作为空间坐标
    coords = point_cloud[:, :3]

    # 最远点采样
    #num_samples = len(point_cloud) // 6
    num_samples = 1000
    sampled_indices, _ = farthest_point_sampling(coords, num_samples)

    # 使用采样的索引提取对应的点云数据（包含所有7个维度）
    sampled_point_cloud = point_cloud[sampled_indices]

    # 保存下采样后的点云数据
    save_point_cloud_to_txt(output_file, sampled_point_cloud)


if __name__ == '__main__':
    input_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    output_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    main(input_file, output_file)
