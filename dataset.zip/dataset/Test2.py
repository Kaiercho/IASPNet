import numpy as np

def read_point_cloud_from_txt(file_path):
    """
    从txt文件中读取点云数据
    """
    point_cloud = np.loadtxt(file_path, delimiter=' ')
    return point_cloud

def random_sampling(point_cloud, num_samples):
    """
    随机采样算法
    :param point_cloud: 输入点云，形状为(N, 7)
    :param num_samples: 需要采样的点数
    :return: 采样后的点云
    """
    N = point_cloud.shape[0]
    if num_samples >= N:
        return point_cloud
    
    sampled_indices = np.random.choice(N, num_samples, replace=False)
    sampled_points = point_cloud[sampled_indices]
    return sampled_points

def save_point_cloud_to_txt(file_path, point_cloud):
    """
    将点云数据保存到txt文件中
    """
    np.savetxt(file_path, point_cloud, delimiter=' ')

def main(input_file, output_file):
    # 读取点云数据
    point_cloud = read_point_cloud_from_txt(input_file)
    
    # 下采样点数为总点数的四分之一
    #num_samples = len(point_cloud) // 4
    num_samples = 1000
    
    # 随机下采样
    sampled_point_cloud = random_sampling(point_cloud, num_samples)
    
    # 保存下采样后的点云数据
    save_point_cloud_to_txt(output_file, sampled_point_cloud)

if __name__ == '__main__':
    input_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    output_file = r"C:\Users\K\Desktop\subsample\ablation\*.txt"
    main(input_file, output_file)
