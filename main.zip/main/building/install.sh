
#!/usr/bin/env bash
# command to install this enviroment: source init.sh
# install miniconda3
#wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
#bash Miniconda3-latest-Linux-x86_64.sh
#source ~/.bashrc 
# module load cuda/11.3.1
# module load gcc/7.5.0
# install
conda create -n env -y python=3.7 numpy=1.20 numba
conda activate env

# please always double check installation for pytorch and torch-scatter
conda install -y pytorch=1.10.1 torchvision cudatoolkit=11.3 -c pytorch -c nvidia
pip install torch-scatter -f https://data.pyg.org/whl/torch-1.10.1+cu113.html
pip install torch-scatter -f https://data.pyg.org/whl/torch-2.0.0+cu118.html
pip install torch-scatter -f https://data.pyg.org/whl/torch-1.13.1+cu116.html

pip install -r requirements.txt
