import torch
import open3d as o3d
import numpy as np

def extract_keypoints(points, alpha):
    """
    参数:
        points (torch.Tensor): 输入的点云数据，维度为 (B, N, C)，其中C通常是3 (x, y, z)。
        alpha (float): Alpha值用于计算alpha shape。

    返回:
        list of torch.Tensor: 每个批次的关键点索引列表。
    """
    B, N, C = points.shape
    keypoints_indices = []

    for i in range(B):
        # 将PyTorch张量转换为NumPy数组
        numpy_points = points[i]
        # numpy_points = points[i].numpy()

        # 创建Open3D点云对象
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(numpy_points)

        # 计算alpha shape
        alpha_shape = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha)
        alpha_shape_vertices = np.asarray(alpha_shape.vertices)

        # 找到原始点云中对应的索引
        kd_tree = o3d.geometry.KDTreeFlann(pcd)
        indices = []
        for vertex in alpha_shape_vertices:
            _, idx, _ = kd_tree.search_knn_vector_3d(vertex, 1)
            indices.append(idx[0])

        # 将索引列表转换为PyTorch张量
        indices_tensor = torch.tensor(indices, dtype=torch.long)
        keypoints_indices.append(indices_tensor)

    return keypoints_indices

# 示例使用
# B, N, C = 2, 1000, 3  # 批次大小, 点的数量, 每个点的特征数量
# points = torch.randn(B, N, C)  # 随机生成点云数据
alpha = 0.5 #0.05  # Alpha值
# points = o3d.io.read_point_cloud("*", format='xyz')
points_1 = np.loadtxt("*")
points_2 = np.loadtxt("*")
points_1 = points_1[0:2000 ,0:3]
points_2 = points_2[0:2000 ,0:3]
points = np.stack((points_1,points_2),axis=0)
keypoints_indices = extract_keypoints(points, alpha)
padded_tensors = torch.nn.utils.rnn.pad_sequence(keypoints_indices, batch_first=True, padding_value=-1)
print("shape:",padded_tensors.shape)
# for batch_idx, indices in enumerate(keypoints_indices):

    # print(f"Batch {batch_idx+1} Key Points Indices: {indices} Shape of keys {len(indices)}")

input_file_path = '*'  # 输入点云数据文件路径
output_file_path = '*'  # 输出轮廓点文件路径
