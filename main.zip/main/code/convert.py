import os
import os.path as osp
import numpy as np
from plyfile import PlyData


filenames = sorted(os.listdir('plydata'))
for filename in filenames:
    with open(osp.join('plydata', filename), 'rb') as f:
        plydata = PlyData.read(f)
    data = plydata['vertex']
    points = np.stack([data['x'], data['y'], data['z']], axis=1)
    feature4 = (data['scalar_Scalar_field']+data['scalar_Scalar_field_#2']+data['scalar_Scalar_field_#3'])/3
    colors = np.stack([data['scalar_Scalar_field'], data['scalar_Scalar_field_#2'], data['scalar_Scalar_field_#3'], feature4], axis=1)
    labels = np.asarray(data['scalar_Scalar_field_#4']).astype(np.int64)
    np.savez_compressed(osp.join('npydata', filename.replace('.ply', '.npz')), points=points, colors=colors, labels=labels)
    point_clouds = np.stack([data['x'], data['y'], data['z'],data['scalar_Scalar_field'], data['scalar_Scalar_field_#2'], data['scalar_Scalar_field_#3'],feature4,data['scalar_Scalar_field_#4']], axis=1)
    np.save(osp.join('npydata', filename.replace('.ply', '.npy')), point_clouds)

